# MyLocationApp

Aplicativo básico para exibir a localização atual usando Expo Location.

## Rodar projeto

```bash
npm install
npx expo install expo-location
npx expo start
```

Abra no seu celular com Expo Go ou no emulador.
